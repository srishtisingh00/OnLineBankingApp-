﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using OnLineBankingApp.Models;

namespace OnLineBankingApp.Controllers
{
    public class OnLineBankingPortalController : Controller
    {
        // GET: OnLineBankingPortalController
        private readonly AppDBContext _context;

        public OnLineBankingPortalController(AppDBContext context)
        {
            _context = context;
        }
        public ActionResult Index()
        {
            ViewData["RoleTypeId"] = new SelectList(_context.RoleTypes, "RoleTypeId", "RoleTypeName");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index([Bind("CustomerID,CustomerName,RoleTypeId,GenderId,DateOfBirth,PAN,Email,Address,City,State,PinCode,Phone,StatusID,Password")] Customer customer)
        {
            Customer cust =await _context.Customers.FirstOrDefaultAsync(c=>c.Email==customer.Email && c.Password == customer.Password);

            HttpContext.Session.SetInt32("CustomerID", cust.CustomerID);

            if (cust!=null)
            {
                if (cust.RoleTypeId==1 && cust.StatusID==2)
                {
                    return RedirectToAction(nameof(Index), "Manager");

                }
                if (cust.RoleTypeId == 2 && cust.StatusID == 2)
                {

                    return RedirectToAction(nameof(DashBoard));
                }


            }


            ViewData["RoleTypeId"] = new SelectList(_context.RoleTypes, "RoleTypeId", "RoleTypeName", customer.RoleTypeId);

            return View(customer);
        }


        public async Task<IActionResult> DashBoard()
        {
            
          int id = Convert.ToInt32(HttpContext.Session.GetInt32("CustomerID"));
            //Customer customer =await _context.Customers.FirstOrDefaultAsync(c=>c.CustomerID==id);

            var customer = await _context.Customers
               .Include(c => c.Gender)
               .Include(c => c.RoleType)
               .Include(c => c.Status)
               .FirstOrDefaultAsync(m => m.CustomerID == id);

            return View(customer);
        }


        public ActionResult SignUp()
        {
            ViewData["GenderId"] = new SelectList(_context.Genders, "GenderId", "GenderType");
            //ViewData["RoleTypeId"] = new SelectList(_context.RoleTypes, "RoleTypeId", "RoleTypeName");
            //ViewData["StatusID"] = new SelectList(_context.Statuss, "StatusID", "StatusType");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SignUp([Bind("CustomerID,CustomerName,RoleTypeId,GenderId,DateOfBirth,PAN,Email,Address,City,State,PinCode,Phone,StatusID,Password")] Customer customer)
        {
           
            if (ModelState.IsValid)
            {
                _context.Add(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["GenderId"] = new SelectList(_context.Genders, "GenderId", "GenderType", customer.GenderId);
            //ViewData["RoleTypeId"] = new SelectList(_context.RoleTypes, "RoleTypeId", "RoleTypeName", customer.RoleTypeId);
            //ViewData["StatusID"] = new SelectList(_context.Statuss, "StatusID", "StatusType", customer.StatusID);
            return View(customer);
        }




        // GET: OnLineBankingPortalController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: OnLineBankingPortalController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: OnLineBankingPortalController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: OnLineBankingPortalController/Edit/5

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            ViewData["GenderId"] = new SelectList(_context.Genders, "GenderId", "GenderType", customer.GenderId);
            ViewData["RoleTypeId"] = new SelectList(_context.RoleTypes, "RoleTypeId", "RoleTypeName", customer.RoleTypeId);
            ViewData["StatusID"] = new SelectList(_context.Statuss, "StatusID", "StatusType", customer.StatusID);
            return View(customer);
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CustomerID,CustomerName,RoleTypeId,GenderId,DateOfBirth,PAN,Email,Address,City,State,PinCode,Phone,StatusID,Password")] Customer customer)
        {
            if (id != customer.CustomerID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(customer.CustomerID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(DashBoard));
            }
            ViewData["GenderId"] = new SelectList(_context.Genders, "GenderId", "GenderType", customer.GenderId);
            ViewData["RoleTypeId"] = new SelectList(_context.RoleTypes, "RoleTypeId", "RoleTypeName", customer.RoleTypeId);
            ViewData["StatusID"] = new SelectList(_context.Statuss, "StatusID", "StatusType", customer.StatusID);
            return View(customer);
        }

        private bool CustomerExists(int id)
        {
            return _context.Customers.Any(e => e.CustomerID == id);
        }




        // GET: OnLineBankingPortalController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: OnLineBankingPortalController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
